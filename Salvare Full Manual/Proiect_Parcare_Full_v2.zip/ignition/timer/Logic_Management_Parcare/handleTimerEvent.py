def handleTimerEvent():
		avarie_path = "[default]Avarie_depasire_timpi"
		val_avarie_noua = system.tag.readBlocking([avarie_path])[0].value

		for i in range(1, 4):
			base_path = "[default]Loc_Parcare_%d/" % i
			tags = system.tag.readBlocking([base_path + "Ocuparea_locului", base_path + "Timp_loc"])
			is_ocupat = tags[0].value
			timp_actual = tags[1].value

			if is_ocupat:
				if timp_actual < 10:
					timp_actual += 1
					system.tag.writeBlocking([base_path + "Timp_loc"], [timp_actual])
				
				if timp_actual >= 10:
					val_avarie_noua = val_avarie_noua | (1 << (i-1))
			else:
				system.tag.writeBlocking([base_path + "Timp_loc"], [0])
				val_avarie_noua = val_avarie_noua & ~(1 << (i-1))

		system.tag.writeBlocking([avarie_path], [val_avarie_noua])